#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import re
from pathlib import Path
from typing import Dict, List, Set, Tuple

import numpy as np
import pandas as pd

# ---------------- Normalization helpers ----------------

_SMELL_MAP = {
    "insufficient modularization": {
        "insufficient modularization", "insuff modularization", "insuff. modularization"
    },
    "greedy service": {"greedy service", "greedy"},
    "hub-like services": {"hub-like services", "hub like services", "hub_like_services", "hub-like"},
    "service intimacy": {"service intimacy", "service intermix", "intimacy"},
    "shared persistency": {"shared persistency", "shared persistence"},
    "unnecessary abstraction": {"unnecessary abstraction", "unnec abstraction"},
    "unversioned api": {"unversioned api", "unversioned-api", "unversioned"},
    "esb usage": {"esb usage", "esb"},
    "broken modularization": {"broken modularization", "broken-modularization"},
    "cyclic dependency": {"cyclic dependency", "unstable dependency", "cycle", "cycles"},
}
_SMELL_CANON: Dict[str, str] = {}
for canon, variants in _SMELL_MAP.items():
    for v in variants:
        _SMELL_CANON[v] = canon

def canon_smell(s: str) -> str:
    if s is None or (isinstance(s, float) and pd.isna(s)):
        return ""
    k = re.sub(r"\s+", " ", str(s).strip().lower())
    return _SMELL_CANON.get(k, k)

def canon_service(s: str) -> str:
    """lowercase, replace _ with -, collapse dashes, drop -service/-services/-svc"""
    if s is None or (isinstance(s, float) and pd.isna(s)):
        return ""
    x = str(s).strip().strip('"').strip("'").lower().replace("_", "-")
    x = re.sub(r"\s+", "", x)
    x = re.sub(r"-(service|services|svc)$", "", x)
    x = re.sub(r"-+", "-", x)
    return x

def split_possible_list(cell: str) -> List[str]:
    """
    Expand GT cells that list multiple services (comma/space separated).
    Auto-prefix 'bookstore-' for known bare names.
    """
    if cell is None or (isinstance(cell, float) and pd.isna(cell)):
        return []
    raw = str(cell)
    toks = re.split(r"[,\s]+", raw.strip())
    out: List[str] = []
    for t in toks:
        t = t.strip().strip('"').strip("'")
        if not t:
            continue
        t = re.sub(r"^[\-\–]+", "", t)  # trim leading dashes
        if not t:
            continue
        cs = canon_service(t)
        if (
            not cs.startswith("bookstore-")
            and re.match(r"^(account|billing|catalog|order|payment|api-gateway|commons|feign)$", cs)
        ):
            cs = "bookstore-" + cs
        out.append(cs)
    return sorted(set(out))

# ---------------- IO helpers ----------------

def _read_any_table(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")
    if path.suffix.lower() in (".xlsx", ".xls"):
        return pd.read_excel(path, dtype=str)
    return pd.read_csv(path, dtype=str)

def load_pairs(
    path: Path,
    smell_cols=("ArchitecturalSmell", "smell", "type", "Smell"),
    svc_cols=("AffectedModule_Service", "service", "module", "Primary Service / Module"),
) -> Set[Tuple[str, str]]:
    df = _read_any_table(path)
    cols = {c.lower().strip(): c for c in df.columns}

    smell_col = next((cols[c.lower()] for c in smell_cols if c.lower() in cols), None)
    svc_col = next((cols[c.lower()] for c in svc_cols if c.lower() in cols), None)
    if smell_col is None or svc_col is None:
        raise ValueError(
            f"{path} missing smell/service columns. "
            f"Looked for smell in {smell_cols} and service in {svc_cols}. "
            f"Columns seen: {list(df.columns)}"
        )

    pairs: Set[Tuple[str, str]] = set()
    for _, r in df.iterrows():
        sm = canon_smell(r.get(smell_col, ""))
        sv_raw = r.get(svc_col, "")
        services = split_possible_list(sv_raw) or [canon_service(sv_raw)]
        for sv in services:
            if sm and sv:
                pairs.add((sm, sv))
    return pairs

def load_capabilities(path: Path) -> Set[str]:
    """Read newline-delimited smells; ignore blanks/# comments."""
    if not path.exists():
        raise FileNotFoundError(f"Capabilities file not found: {path}")
    caps: Set[str] = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        caps.add(canon_smell(line))
    return {c for c in caps if c}

# ---------------- Metrics ----------------

def eval_pairs(pred_pairs: Set[Tuple[str, str]], gt_pairs: Set[Tuple[str, str]]):
    tp = len(pred_pairs & gt_pairs)
    fp = len(pred_pairs - gt_pairs)
    fn = len(gt_pairs - pred_pairs)
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    return tp, fp, fn, precision, recall, f1

# ---------------- Main ----------------

def main():
    ap = argparse.ArgumentParser(
        description="Compare multiple smell prediction files against a single GT, "
                    "with optional per-project capability scopes."
    )
    ap.add_argument("--gt", required=True, help="Ground truth CSV/XLSX")
    ap.add_argument(
        "--pred",
        action="append",
        required=True,
        help="Prediction CSV/XLSX. Repeatable. Use LABEL=path to set label.",
    )
    ap.add_argument(
        "--cap",
        action="append",
        default=[],
        help="Optional capability file per project. Use LABEL=path to attach capabilities to a LABEL used in --pred.",
    )
    ap.add_argument("--summary-out", default="comparison_summary.csv", help="Summary CSV output")
    ap.add_argument("--details-out-dir", default="", help="Optional folder for TP/FP/FN breakdown per project")
    args = ap.parse_args()

    gt_pairs_all = load_pairs(Path(args.gt))

    # Parse --pred list
    pred_specs: Dict[str, Path] = {}
    for item in args.pred:
        if "=" in item:
            label, p = item.split("=", 1)
        else:
            p = item
            label = Path(p).stem
        pred_specs[label] = Path(p)

    # Parse --cap list: LABEL=file
    cap_specs: Dict[str, Set[str]] = {}
    for c in args.cap:
        if "=" not in c:
            raise ValueError("Each --cap must be LABEL=path/to/capabilities.txt")
        label, p = c.split("=", 1)
        cap_specs[label] = load_capabilities(Path(p))

    rows = []
    detail_dir = Path(args.details_out_dir) if args.details_out_dir else None
    if detail_dir:
        detail_dir.mkdir(parents=True, exist_ok=True)

    for label, ppath in pred_specs.items():
        pred_pairs = load_pairs(ppath)

        # Capability scope for this project (if provided)
        caps = cap_specs.get(label)
        if caps:
            pred_pairs_scoped = {(sm, sv) for (sm, sv) in pred_pairs if sm in caps}
            gt_pairs_scoped = {(sm, sv) for (sm, sv) in gt_pairs_all if sm in caps}
            scope_note = f"{len(caps)} smells"
        else:
            pred_pairs_scoped = pred_pairs
            gt_pairs_scoped = gt_pairs_all
            scope_note = "ALL"

        tp, fp, fn, p, r, f1 = eval_pairs(pred_pairs_scoped, gt_pairs_scoped)
        rows.append(
            {
                "Project": label,
                "Scope": scope_note,
                "TP": tp,
                "FP": fp,
                "FN": fn,
                "Precision": round(p, 3),
                "Recall": round(r, 3),
                "F1": round(f1, 3),
                "Support(GT_scoped)": len(gt_pairs_scoped),
            }
        )

        if detail_dir:
            det = []
            for (s, v) in sorted(pred_pairs_scoped & gt_pairs_scoped):
                det.append({"set": "TP", "smell": s, "service": v})
            for (s, v) in sorted(pred_pairs_scoped - gt_pairs_scoped):
                det.append({"set": "FP", "smell": s, "service": v})
            for (s, v) in sorted(gt_pairs_scoped - pred_pairs_scoped):
                det.append({"set": "FN", "smell": s, "service": v})
            pd.DataFrame(det).to_csv(detail_dir / f"{label}_details.csv", index=False)

    summary = pd.DataFrame(rows).sort_values(["F1", "Precision", "Recall"], ascending=[False, False, False])
    summary.to_csv(args.summary_out, index=False)
    print(f"✓ Wrote summary → {args.summary_out}")
    if detail_dir:
        print(f"✓ Wrote per-project details → {detail_dir}/<label>_details.csv")

if __name__ == "__main__":
    main()
