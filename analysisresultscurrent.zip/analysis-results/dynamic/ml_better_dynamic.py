#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dynamic Micro-service Architectural Smell Detector — v17.0 (unsupervised-ensemble, balanced)
===========================================================================================

What this version does (out-of-the-box, no per-project tweaks):
- **Tolerant loader** for `tags_dict` (JSON or Python-dict strings).
- **Unsupervised ML ensemble** per smell: IsolationForest with multiple seeds; keep
  only **stable anomalies** (majority vote across seeds) to reduce noise.
- **Balanced hybrid**: RULES ∪ (ML_strong ∩ evidence) ∪ (weak tail ∩ stronger evidence).
  No infra suppression by default (so config/discovery/admin can be hubs if the data says so).
- Deterministic high-precision checks kept as rules (e.g., Unversioned API).
- Optional `--explain` emits features and score files for audit.
- Optional `--gt path.csv` prints TP/FP/FN, Precision/Recall/F1/IoU-Accuracy for quick evaluation.

Usage examples:
  python ml_better_dynamic.py traces.csv --mode hybrid --explain
  python ml_better_dynamic.py traces.csv --mode ml --explain
  python ml_better_dynamic.py traces.csv --mode rules
  python ml_better_dynamic.py traces.csv --mode hybrid --gt ground_truth.csv
"""
from __future__ import annotations

import argparse, json, re, sys, ast
from pathlib import Path
from typing import Set, Tuple, List, Dict
from urllib.parse import urlparse

import networkx as nx
import numpy as np
import pandas as pd

from sklearn.cluster import DBSCAN
from sklearn.ensemble import IsolationForest
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import RobustScaler

# ───────────────────────── helpers ──────────────────────────

def robust_z(arr: np.ndarray) -> np.ndarray:
    x = np.asarray(arr, dtype=float)
    med = np.median(x, axis=0)
    mad = np.median(np.abs(x - med), axis=0) * 1.4826 + 1e-9
    return (x - med) / mad

def first_segment(path: str) -> str:
    return path.lstrip("/").split("/", 1)[0].lower() if isinstance(path, str) else ""

def parse_cont_map(s: str|None) -> Dict[str, float]:
    out: Dict[str, float] = {}
    if not s: return out
    for tok in s.split(","):
        tok = tok.strip()
        if not tok: continue
        k, _, v = tok.partition(":")
        try:
            out[k.strip()] = float(v.strip())
        except:
            pass
    return out

def quantile(series: pd.Series, q: float, default: float = float("inf")) -> float:
    if series is None or series.empty: return default
    q = max(0.0, min(1.0, q))
    return float(series.quantile(q))

def iqr_bar(series: pd.Series, k: float = 0.5, default: float = float("inf")) -> float:
    if series is None or series.empty: return default
    q1 = series.quantile(0.25)
    med = series.quantile(0.50)
    q3 = series.quantile(0.75)
    return float(med + k*(q3 - q1))

def strong_ids(score: pd.Series, contamination: float) -> Set[str]:
    if score is None or score.empty: return set()
    q_bar = quantile(score, 1.0 - min(max(contamination, 0.01), 0.49))
    iqr    = iqr_bar(score, 0.5)
    thr = max(q_bar, iqr)
    return set(score[score >= thr].index)

# ────────────────────── load & prep ─────────────────────────

def _safe_parse_tags(s):
    """Tolerant parser for tags_dict values.
    - Tries strict JSON first
    - Falls back to ast.literal_eval for Python-style dict strings
    - Returns {} on any failure or nulls
    """
    if s is None or (isinstance(s, float) and np.isnan(s)):
        return {}
    if not isinstance(s, str):
        return {}
    s_strip = s.strip()
    if s_strip in ("", "null", "None"):
        return {}
    try:
        return json.loads(s_strip)
    except Exception:
        try:
            v = ast.literal_eval(s_strip)
            return v if isinstance(v, dict) else {}
        except Exception:
            return {}

def load_traces(csv_path: Path) -> pd.DataFrame:
    df = (
        pd.read_csv(csv_path, dtype=str)
          .rename(columns={
              "serviceName":   "service",
              "operationName": "operation",
              "tags_dict":     "tags_dict",
              "traceId":       "traceId",
              "timestamp":     "timestamp",
          })
    )
    df["tags_dict"] = df.get("tags_dict", pd.Series([None]*len(df))).apply(_safe_parse_tags)
    for col in ("spanId", "parentId"):
        if col not in df.columns:
            df[col] = None
    if "duration" in df.columns:
        df["duration"] = pd.to_numeric(df["duration"], errors="coerce")
    raw_ts = df.get("timestamp")
    ts_numeric = pd.to_numeric(raw_ts, errors="coerce")
    # Zipkin timestamps are microseconds since epoch (e.g. 1786274224759011);
    # generic date parsing can't infer that from a bare integer and silently
    # falls back to "now" for every row, which destroys within-trace ordering.
    df["ts"] = pd.to_datetime(ts_numeric, unit="us", errors="coerce", utc=True)
    still_missing = df["ts"].isna()
    if still_missing.any():
        df.loc[still_missing, "ts"] = pd.to_datetime(raw_ts[still_missing], errors="coerce", utc=True)
    df["ts"] = df["ts"].fillna(pd.Timestamp.now("UTC")).dt.tz_convert(None)

    span2svc = dict(zip(df["spanId"], df["service"]))
    df["caller"] = df["parentId"].map(span2svc)

    df["operation"] = df["operation"].fillna("").astype(str).str.strip().str.lower()
    return df

# ─────────────────── graph builders ────────────────────────

def build_parent_graph(df: pd.DataFrame) -> nx.DiGraph:
    G = nx.DiGraph()
    for _, r in df.dropna(subset=["caller"]).iterrows():
        if r.caller and r.service and r.caller != r.service:
            w = G.get_edge_data(r.caller, r.service, {"w":0})["w"] + 1
            G.add_edge(r.caller, r.service, w=w)
    return G

# ─────────────────── feature engineering ────────────────────

def pick_db_tag(tags: dict) -> str|None:
    if not isinstance(tags, dict): return None
    for k in ("db.instance","db.name","db.system","jdbc.url","db.jdbc.url","peer.address"):
        if k in tags and tags[k]:
            s = str(tags[k])
            if s.startswith("jdbc"):
                try:
                    p = urlparse(s.split("jdbc:")[-1].lstrip("/"))
                    host = p.hostname or ""
                    port = f":{p.port}" if p.port else ""
                    path = p.path.lstrip("/")
                    return f"{host}{port}/{path}" if host else s
                except Exception:
                    return s
            return s
    return None

def make_service_features(df: pd.DataFrame) -> pd.DataFrame:
    svcs = sorted(set(df["service"].dropna()))
    if not svcs:
        return pd.DataFrame()

    G = build_parent_graph(df)
    indeg  = dict(G.in_degree())
    outdeg = dict(G.out_degree())
    betw   = nx.betweenness_centrality(G, normalized=True) if G.number_of_nodes() else {}

    lat = (df.groupby("service")["duration"].agg(['mean','median','max','std','count']).rename(columns={'count':'calls'}))
    lat = lat.reindex(svcs).fillna(0)

    op_count = df.groupby("service")["operation"].nunique().reindex(svcs).fillna(0).astype(float)

    segs = (df.assign(seg=df["operation"].map(first_segment))
              .groupby(["service","seg"]).size().unstack(fill_value=0))
    seg_max = segs.max(axis=1).reindex(svcs).fillna(0).astype(float)
    seg_p = segs.div(segs.sum(axis=1).replace(0,1), axis=0).replace({0:1e-12})
    seg_entropy = (-(seg_p * np.log2(seg_p)).sum(axis=1)).reindex(svcs).fillna(0).astype(float)

    H = nx.DiGraph()
    span2svc = dict(zip(df["spanId"], df["service"]))
    for _, r in df.dropna(subset=["parentId","service"]).iterrows():
        a = span2svc.get(r.parentId); b = r.service
        if a and b and a != b:
            H.add_edge(a, b, w=H.get_edge_data(a, b, {"w": 0})["w"] + 1)

    total: dict[str, float] = {}
    for s in svcs:
        if H.has_node(s):
            in_w  = sum(H.get_edge_data(t, s, {"w": 0})["w"] for t in H.predecessors(s))
            out_w = sum(H.get_edge_data(s, t, {"w": 0})["w"] for t in H.successors(s))
        else:
            in_w = out_w = 0
        total[s] = float(in_w + out_w)

    best_mutual, best_ratio = [], []
    for s in svcs:
        m = 0.0
        if H.has_node(s):
            neigh = set(H.successors(s)) | set(H.predecessors(s))
            for t in neigh:
                m = max(m, float(
                    H.get_edge_data(s, t, {"w": 0})["w"] +
                    H.get_edge_data(t, s, {"w": 0})["w"]
                ))
        best_mutual.append(m)
        denom = total.get(s, 0.0)
        best_ratio.append(m / (denom or 1.0))

    d2 = df.copy()
    d2["db"] = d2["tags_dict"].apply(pick_db_tag)
    svc_db_cnt = d2[d2.db.notna()].groupby("service")["db"].nunique().reindex(svcs).fillna(0).astype(float)

    feats = pd.DataFrame({
        "in_deg":   [indeg.get(s,0) for s in svcs],
        "out_deg":  [outdeg.get(s,0) for s in svcs],
        "betw":     [betw.get(s,0.0) for s in svcs],
        "lat_mean": lat["mean"].values,
        "lat_med":  lat["median"].values,
        "lat_max":  lat["max"].values,
        "lat_std":  lat["std"].fillna(0).values,
        "calls":    lat["calls"].values,
        "op_count": op_count.values,
        "seg_max":  seg_max.values,
        "seg_entropy": seg_entropy.values,
        "intimacy_best_mutual": np.array(best_mutual, dtype=float),
        "intimacy_best_ratio":  np.array(best_ratio, dtype=float),
        "db_count": svc_db_cnt.values,
    }, index=svcs).replace([np.inf,-np.inf], 0).fillna(0)

    scaler = RobustScaler()
    feats_scaled = pd.DataFrame(
        scaler.fit_transform(feats.values),
        index=feats.index,
        columns=feats.columns
    )
    feats_scaled.attrs["unscaled"] = feats
    return feats_scaled

# ─────────────────── rules detectors ───────────────────────

def detect_broken_mod_rules(df: pd.DataFrame) -> Set[str]:
    victims: Set[str] = set()
    ops = df["operation"].dropna().unique()
    if len(ops) >= 4:
        vec    = TfidfVectorizer().fit_transform(ops)
        labels = DBSCAN(eps=0.5, min_samples=2, metric="cosine").fit_predict(vec)
        tmp    = pd.DataFrame({"op": ops, "cluster": labels})
        sizes  = tmp[tmp.cluster != -1].groupby("cluster").size()
        bad    = sizes[sizes > sizes.mean() + sizes.std()].index
        victims.update(
            df[df["operation"].isin(tmp[tmp.cluster.isin(bad)]["op"])] ["service"].unique()
        )
    return set(map(str, victims))

def detect_insufficient_mod_rules(df: pd.DataFrame) -> Set[str]:
    G = build_parent_graph(df)
    svcs = list(G.nodes)
    if not svcs:
        return set()
    df["op"] = df["operation"].fillna("").astype(str)
    calls_in  = pd.Series({s:G.in_degree(s) for s in svcs})
    calls_out = pd.Series({s:G.out_degree(s) for s in svcs})
    internal  = pd.Series({s:G.get_edge_data(s, s, default={"w":0})["w"] for s in svcs})
    calls = (calls_in + calls_out + internal).replace(0, 1)
    cohesion = internal / calls
    op_count = df.groupby("service")["op"].nunique().reindex(svcs).fillna(0).astype(int)
    flagged = set(op_count[(op_count >= 3) & (cohesion <= 0.6)].index)
    return set(map(str, flagged))

def detect_cyclic_dependency_rules(df: pd.DataFrame) -> Set[str]:
    # Only the parent graph (built from real span parent/child, i.e. actual
    # caller->callee edges) reflects true call direction. The sequence/cycle
    # graphs derive edges from chronological service order within a trace,
    # which records a synchronous RPC returning control to its caller as a
    # spurious reverse edge -- every normal A calls B, then A calls C pattern
    # looks like an A->B->A cycle even though B never called A back.
    cyc: Set[str] = set()
    G = build_parent_graph(df)
    if G.number_of_nodes() > 0:
        cyc.update({
            n for comp in nx.strongly_connected_components(G)
            if len(comp) > 1 for n in comp
        })
        cyc.update({u for u, v in G.edges() if G.has_edge(v, u)})
    return set(map(str, cyc))

def detect_greedy_service_rules(df: pd.DataFrame, z_cut: float, ratio: float, top: int) -> Set[str]:
    if "duration" not in df.columns:
        return set()
    agg = df.groupby("service")["duration"].agg(["mean", "max", "count"]).rename(columns={"count":"calls"})
    z            = robust_z(agg[["mean", "max", "calls"]])
    cond_z       = (np.abs(z) > z_cut).any(axis=1)
    med_lat      = agg[["mean", "max"]].median()
    cond_latency = (agg["mean"] >= med_lat["mean"]*ratio) | (agg["max"] >= med_lat["max"]*ratio)
    med_calls    = agg["calls"].median()
    cond_calls   = agg["calls"] >= med_calls*ratio
    greedy       = set(agg[cond_z | cond_latency | cond_calls].index)
    greedy.update(agg.nlargest(min(top, len(agg)), "calls").index)
    return set(map(str, greedy))

def detect_hub_like_rules(df: pd.DataFrame, deg_pct: int, betw_pct: int, hints: Set[str]) -> Set[str]:
    G = build_parent_graph(df)
    if G.number_of_nodes() == 0:
        return set()
    degs = pd.Series(dict(G.degree()))
    hubs = set(degs[degs >= np.percentile(degs.values, deg_pct)].index)
    betw = pd.Series(nx.betweenness_centrality(G, normalized=True))
    hubs.update(betw[betw >= np.percentile(betw.values, betw_pct)].index)
    hubs.update({svc for svc in G.nodes() if any(h in str(svc).lower() for h in hints)})
    return set(map(str, hubs))

# ─────────────── merged Service Intimacy ──────────────────

def detect_service_intimacy_rules(df: pd.DataFrame, ratio: float, min_calls: int) -> Set[str]:
    G = nx.DiGraph()
    span2svc = dict(zip(df["spanId"], df["service"]))
    for _, r in df.dropna(subset=["parentId", "service"]).iterrows():
        src = span2svc.get(r.parentId)
        dst = r.service
        if src and dst and src != dst:
            w = G.get_edge_data(src, dst, {"w":0})["w"] + 1
            G.add_edge(src, dst, w=w)
    total = { s: G.in_degree(s, weight="w") + G.out_degree(s, weight="w") for s in G.nodes() }
    intimate = set()
    for s in G.nodes():
        best = 0
        for t in set(G.successors(s)) | set(G.predecessors(s)):
            mutual = (
                G.get_edge_data(s, t, {"w":0})["w"] +
                G.get_edge_data(t, s, {"w":0})["w"]
            )
            best = max(best, mutual)
        if best >= min_calls and total.get(s, 0) > 0 and best / total[s] >= ratio:
            intimate.add(s)
    return set(map(str, intimate))

def detect_shared_persistency_rules(df: pd.DataFrame, min_providers: int) -> Set[str]:
    d2 = df.copy()
    d2["db"] = d2["tags_dict"].apply(pick_db_tag)
    shared = d2[d2.db.notna()].groupby("db")["service"].nunique()
    valid = set(shared[shared >= min_providers].index)
    return set(map(str, d2[d2.db.isin(valid)]["service"].unique()))

def detect_unnecessary_abstraction_rules(df: pd.DataFrame, z_cut: float) -> Set[str]:
    if "duration" not in df.columns:
        return set()
    stats = df.groupby("operation")["duration"].agg(["var","count"]).fillna(0)
    mask = (np.abs(robust_z(stats[["var","count"]])) > z_cut).any(axis=1)
    bad_ops = stats[mask].index
    return set(map(str, df[df["operation"].isin(bad_ops)]["service"].unique()))

def detect_unversioned_api_rules(df: pd.DataFrame) -> Set[str]:
    bad_ops = [op for op in df["operation"].dropna().unique() if not re.match(r"^/v\d+", op)]
    return set(map(str, df[df["operation"].isin(bad_ops)]["service"].unique()))

def detect_esb_usage_rules(df: pd.DataFrame, pct: int) -> Set[str]:
    by_path = set(df[df["operation"].str.contains("esb", case=False, na=False)]["service"])
    G = build_parent_graph(df)
    if G.number_of_nodes() < 3:
        return set(map(str, by_path))
    betw = pd.Series(nx.betweenness_centrality(G, normalized=True))
    fan  = pd.Series(dict(G.out_degree()))
    thr_b = np.percentile(betw.values, pct)
    thr_f = np.percentile(fan.values, pct)
    hubs = set(betw[(betw >= thr_b) & (fan >= thr_f)].index)
    return set(map(str, (by_path | hubs)))

# ─────────────────── ML primitives ─────────────────────────

def iforest_scores(X: pd.DataFrame, cols: List[str], contamination: float, seed: int) -> pd.Series:
    use = [c for c in cols if c in X.columns]
    if X.empty or not use:
        return pd.Series(dtype=float)
    c = max(min(contamination, 0.49), 0.01)
    clf = IsolationForest(contamination=c, random_state=seed)
    clf.fit(X[use])
    return pd.Series(-clf.score_samples(X[use]), index=X.index)  # higher = more anomalous

def iforest_scores_seeds(X: pd.DataFrame, cols: List[str], contamination: float, seeds: List[int]) -> tuple[Dict[int,pd.Series], pd.Series]:
    by_seed: Dict[int,pd.Series] = {}
    for sd in seeds:
        by_seed[sd] = iforest_scores(X, cols, contamination, sd)
    # mean score across seeds
    df_scores = pd.concat(by_seed.values(), axis=1)
    df_scores.columns = [f"seed_{sd}" for sd in by_seed.keys()]
    mean_score = df_scores.mean(axis=1)
    return by_seed, mean_score

# ─────────────────── smell detectors (ML) ──────────────────

def detect_insufficient_mod_ml(X: pd.DataFrame, cont: float, seeds: List[int]) -> tuple[Set[str], pd.Series, Dict[int,pd.Series]]:
    cols = ["op_count","seg_max","seg_entropy","in_deg","out_deg","calls"]
    by_seed, mean_score = iforest_scores_seeds(X, cols, cont, seeds)
    # stability: service must be in strong tail in >= ceil(0.6 * n_seeds)
    votes = {}
    for sd, sc in by_seed.items():
        for sid in strong_ids(sc, cont):
            votes[sid] = votes.get(sid, 0) + 1
    min_votes = int(np.ceil(0.6 * max(1, len(seeds))))
    stable = {s for s, v in votes.items() if v >= min_votes}
    return stable, mean_score, by_seed

def detect_greedy_service_ml(X: pd.DataFrame, cont: float, seeds: List[int]) -> tuple[Set[str], pd.Series, Dict[int,pd.Series]]:
    cols = ["lat_mean","lat_max","lat_std","calls"]
    by_seed, mean_score = iforest_scores_seeds(X, cols, cont, seeds)
    votes = {}
    for sd, sc in by_seed.items():
        for sid in strong_ids(sc, cont):
            votes[sid] = votes.get(sid, 0) + 1
    min_votes = int(np.ceil(0.6 * max(1, len(seeds))))
    stable = {s for s, v in votes.items() if v >= min_votes}
    return stable, mean_score, by_seed

def detect_hub_like_ml(X: pd.DataFrame, cont: float, seeds: List[int]) -> tuple[Set[str], pd.Series, Dict[int,pd.Series]]:
    cols = ["in_deg","out_deg","betw"]
    by_seed, mean_score = iforest_scores_seeds(X, cols, cont, seeds)
    votes = {}
    for sd, sc in by_seed.items():
        for sid in strong_ids(sc, cont):
            votes[sid] = votes.get(sid, 0) + 1
    min_votes = int(np.ceil(0.6 * max(1, len(seeds))))
    stable = {s for s, v in votes.items() if v >= min_votes}
    return stable, mean_score, by_seed

def detect_service_intimacy_ml(X: pd.DataFrame, cont: float, seeds: List[int]) -> tuple[Set[str], pd.Series, Dict[int,pd.Series]]:
    cols = ["intimacy_best_ratio","intimacy_best_mutual"]
    by_seed, mean_score = iforest_scores_seeds(X, cols, cont, seeds)
    votes = {}
    for sd, sc in by_seed.items():
        for sid in strong_ids(sc, cont):
            votes[sid] = votes.get(sid, 0) + 1
    min_votes = int(np.ceil(0.6 * max(1, len(seeds))))
    stable = {s for s, v in votes.items() if v >= min_votes}
    return stable, mean_score, by_seed

def detect_shared_persistency_ml(X: pd.DataFrame, cont: float, seeds: List[int]) -> tuple[Set[str], pd.Series, Dict[int,pd.Series]]:
    cols = ["db_count"]
    by_seed, mean_score = iforest_scores_seeds(X, cols, cont, seeds)
    votes = {}
    for sd, sc in by_seed.items():
        for sid in strong_ids(sc, cont):
            votes[sid] = votes.get(sid, 0) + 1
    min_votes = int(np.ceil(0.6 * max(1, len(seeds))))
    stable = {s for s, v in votes.items() if v >= min_votes}
    return stable, mean_score, by_seed

def detect_unnecessary_abstraction_ml(X: pd.DataFrame, cont: float, seeds: List[int]) -> tuple[Set[str], pd.Series, Dict[int,pd.Series]]:
    cols = ["lat_std","lat_mean","calls"]
    by_seed, mean_score = iforest_scores_seeds(X, cols, cont, seeds)
    votes = {}
    for sd, sc in by_seed.items():
        for sid in strong_ids(sc, cont):
            votes[sid] = votes.get(sid, 0) + 1
    min_votes = int(np.ceil(0.6 * max(1, len(seeds))))
    stable = {s for s, v in votes.items() if v >= min_votes}
    return stable, mean_score, by_seed

def detect_esb_usage_ml(X: pd.DataFrame, cont: float, seeds: List[int]) -> tuple[Set[str], pd.Series, Dict[int,pd.Series]]:
    cols = ["betw","out_deg"]
    by_seed, mean_score = iforest_scores_seeds(X, cols, cont, seeds)
    votes = {}
    for sd, sc in by_seed.items():
        for sid in strong_ids(sc, cont):
            votes[sid] = votes.get(sid, 0) + 1
    min_votes = int(np.ceil(0.6 * max(1, len(seeds))))
    stable = {s for s, v in votes.items() if v >= min_votes}
    return stable, mean_score, by_seed

# ─────────────────── hybrid combination ────────────────────

def combine_balanced(rule_set: Set[str], mean_score: pd.Series, stable_strong: Set[str], evidence: pd.Series|None,
                      contamination: float) -> Set[str]:
    """Balanced union used by default.
    final = RULES ∪ (STRONG ∩ ev60) ∪ (WEAK ∩ ev70)
    where WEAK are top-k by mean score with k ≈ contamination*n.
    """
    n = len(mean_score) if isinstance(mean_score, pd.Series) else 0
    k = int(np.ceil(max(1, n * min(max(contamination, 0.01), 0.49))))

    weak = set()
    if isinstance(mean_score, pd.Series) and n:
        weak = set(mean_score.sort_values(ascending=False).head(k).index)

    ev60 = set(mean_score.index)
    ev70 = set(mean_score.index)
    if isinstance(evidence, pd.Series) and len(evidence):
        thr60 = evidence.quantile(0.60)
        thr70 = evidence.quantile(0.70)
        ev60 = {s for s in evidence.index if evidence.loc[s] >= thr60}
        ev70 = {s for s in evidence.index if evidence.loc[s] >= thr70}

    strong_part = set(stable_strong) & ev60
    weak_part   = weak & ev70
    return set(rule_set) | strong_part | weak_part

# ───────────────────────── main ─────────────────────────────

def parse_gt(path: Path) -> Set[tuple[str,str]]:
    if not path or not path.exists():
        return set()
    df = pd.read_csv(path, dtype=str)
    df = df.rename(columns={"ArchitecturalSmell":"ArchitecturalSmell","AffectedModule_Service":"AffectedModule_Service"})
    df = df.dropna(subset=["ArchitecturalSmell","AffectedModule_Service"])
    return set(map(tuple, df[["ArchitecturalSmell","AffectedModule_Service"]].values.tolist()))


def main() -> None:
    ap = argparse.ArgumentParser(description="Detect dynamic architectural smells (v17.0)")
    ap.add_argument("csv", help="Zipkin CSV file")
    ap.add_argument("-o", "--output", default="smells.csv", help="Output CSV")

    ap.add_argument("--mode", choices=["rules","ml","hybrid"], default="hybrid",
                    help="Detection strategy per smell")
    ap.add_argument("--explain", action="store_true", help="Export features and anomaly scores")
    ap.add_argument("--gt", type=str, default="", help="Optional ground-truth CSV for quick metrics")

    ap.add_argument("--contamination", type=float, default=0.22,
                    help="Default contamination when per-smell not provided (0.01..0.49)")
    ap.add_argument("--cont-map", type=str, default="",
                    help="Per-smell contamination overrides, e.g. 'greedy:0.25,hub:0.20,intimacy:0.22'")

    # rule params
    ap.add_argument("--z",        type=float, default=1.5)
    ap.add_argument("--greedy-ratio", type=float, default=1.2)
    ap.add_argument("--greedy-z",     type=float, default=1.1)
    ap.add_argument("--greedy-top",   type=int,   default=20)
    ap.add_argument("--hub-pct",   type=int, default=60)
    ap.add_argument("--betw-pct",  type=int, default=80)
    ap.add_argument("--hub-hints",
                    type=lambda s: {w.strip().lower() for w in s.split(",") if w.strip()},
                    default=set())
    ap.add_argument("--ratio",     type=float, default=0.25)
    ap.add_argument("--min-calls", type=int,   default=5)
    ap.add_argument("--sp-min",    type=int, default=2)

    args = ap.parse_args()
    df = load_traces(Path(args.csv))
    if df.empty:
        print("No rows loaded from CSV. Exiting.", file=sys.stderr); sys.exit(1)

    X = make_service_features(df)
    unscaled = X.attrs.get("unscaled", pd.DataFrame(index=X.index)) if not X.empty else pd.DataFrame()

    cmap = {
        "insuff": 0.25, "greedy": 0.25, "hub": 0.20, "intimacy": 0.22,
        "sp": 0.20, "ua": 0.20, "esb": 0.15
    }
    cmap.update(parse_cont_map(args.cont_map))
    def cget(key: str) -> float:
        return max(min(cmap.get(key, args.contamination), 0.49), 0.01)

    results: list[tuple[str,str]] = []
    scores_out: Dict[str, pd.DataFrame|pd.Series] = {}

    # Structural rules (kept regardless of mode)
    bm = detect_broken_mod_rules(df)
    cd = detect_cyclic_dependency_rules(df)

    # RULES baseline
    gs_rules = detect_greedy_service_rules(df, args.greedy_z, args.greedy_ratio, args.greedy_top)
    hub_rules = detect_hub_like_rules(df, args.hub_pct, args.betw_pct, args.hub_hints)
    im_rules = detect_insufficient_mod_rules(df)
    si_rules = detect_service_intimacy_rules(df, args.ratio, args.min_calls)
    sp_rules = detect_shared_persistency_rules(df, args.sp_min)
    ua_rules = detect_unnecessary_abstraction_rules(df, args.z)
    uv_rules = detect_unversioned_api_rules(df)
    esb_rules = detect_esb_usage_rules(df, args.betw_pct)

    seeds = [0, 1, 2, 3, 4]

    if args.mode == "rules":
        im = im_rules; gs = gs_rules; hub = hub_rules; si = si_rules; sp = sp_rules; ua = ua_rules; uv = uv_rules; esb = esb_rules
    elif args.mode == "ml":
        im_stable, sc_im_mean, sc_im = detect_insufficient_mod_ml(X, cget("insuff"), seeds);   scores_out["Insufficient_Modularization_scores"] = pd.DataFrame(sc_im)
        gs_stable, sc_gs_mean, sc_gs = detect_greedy_service_ml(X, cget("greedy"), seeds);     scores_out["Greedy_Service_scores"] = pd.DataFrame(sc_gs)
        hub_stable, sc_hu_mean, sc_hu = detect_hub_like_ml(X, cget("hub"), seeds);             scores_out["Hub_like_scores"] = pd.DataFrame(sc_hu)
        si_stable, sc_si_mean, sc_si = detect_service_intimacy_ml(X, cget("intimacy"), seeds);  scores_out["Service_Intimacy_scores"] = pd.DataFrame(sc_si)
        sp_stable, sc_sp_mean, sc_sp = detect_shared_persistency_ml(X, cget("sp"), seeds);      scores_out["Shared_Persistency_scores"] = pd.DataFrame(sc_sp)
        ua_stable, sc_ua_mean, sc_ua = detect_unnecessary_abstraction_ml(X, cget("ua"), seeds); scores_out["Unnecessary_Abstraction_scores"] = pd.DataFrame(sc_ua)
        esb_stable, sc_es_mean, sc_es= detect_esb_usage_ml(X, cget("esb"), seeds);              scores_out["ESB_scores"] = pd.DataFrame(sc_es)

        im  = set(im_stable)
        gs  = set(gs_stable)
        hub = set(hub_stable)
        si  = set(si_stable)
        sp  = set(sp_stable)
        ua  = set(ua_stable)
        esb = set(esb_stable)
        uv  = uv_rules  # deterministic
    else:
        # HYBRID balanced
        im_stable, sc_im_mean, sc_im = detect_insufficient_mod_ml(X, cget("insuff"), seeds);   scores_out["Insufficient_Modularization_scores"] = pd.DataFrame(sc_im)
        gs_stable, sc_gs_mean, sc_gs = detect_greedy_service_ml(X, cget("greedy"), seeds);     scores_out["Greedy_Service_scores"] = pd.DataFrame(sc_gs)
        hub_stable, sc_hu_mean, sc_hu = detect_hub_like_ml(X, cget("hub"), seeds);             scores_out["Hub_like_scores"] = pd.DataFrame(sc_hu)
        si_stable, sc_si_mean, sc_si = detect_service_intimacy_ml(X, cget("intimacy"), seeds);  scores_out["Service_Intimacy_scores"] = pd.DataFrame(sc_si)
        sp_stable, sc_sp_mean, sc_sp = detect_shared_persistency_ml(X, cget("sp"), seeds);      scores_out["Shared_Persistency_scores"] = pd.DataFrame(sc_sp)
        ua_stable, sc_ua_mean, sc_ua = detect_unnecessary_abstraction_ml(X, cget("ua"), seeds); scores_out["Unnecessary_Abstraction_scores"] = pd.DataFrame(sc_ua)
        esb_stable, sc_es_mean, sc_es= detect_esb_usage_ml(X, cget("esb"), seeds);              scores_out["ESB_scores"] = pd.DataFrame(sc_es)

        im  = combine_balanced(im_rules,  sc_im_mean,  im_stable,  X.get("op_count"),            cget("insuff"))
        gs  = combine_balanced(gs_rules,  sc_gs_mean,  gs_stable,  X.get("lat_mean"),            cget("greedy"))
        hub = combine_balanced(hub_rules, sc_hu_mean,  hub_stable, X.get("in_deg")+X.get("out_deg"), cget("hub"))
        si  = combine_balanced(si_rules,  sc_si_mean,  si_stable,  X.get("intimacy_best_ratio"), cget("intimacy"))
        sp  = combine_balanced(sp_rules,  sc_sp_mean,  sp_stable,  X.get("db_count"),            cget("sp"))
        ua  = combine_balanced(ua_rules,  sc_ua_mean,  ua_stable,  X.get("lat_std"),             cget("ua"))
        esb = combine_balanced(esb_rules, sc_es_mean,  esb_stable, X.get("betw"),                cget("esb"))
        uv  = uv_rules

    # Collect & write
    out: list[tuple[str,str]] = []
    out += [("Insufficient Modularization", s) for s in sorted(im)]
    out += [("Greedy Service", s) for s in sorted(gs)]
    out += [("Hub-like Services", s) for s in sorted(hub)]
    out += [("Service Intimacy", s) for s in sorted(si)]
    out += [("Shared Persistency", s) for s in sorted(sp)]
    out += [("Unnecessary Abstraction", s) for s in sorted(ua)]
    out += [("Unversioned API", s) for s in sorted(uv)]
    out += [("ESB Usage", s) for s in sorted(esb)]

    # Always include structural ones
    out += [("Broken Modularization", s) for s in sorted(bm)]
    out += [("Cyclic Dependency", s) for s in sorted(cd)]

    pd.DataFrame(out, columns=["ArchitecturalSmell","AffectedModule_Service"]).drop_duplicates().to_csv(args.output, index=False)
    print(f"✓ Smell summary written → {args.output} (mode={args.mode}, n={len(out)})")

    # Optional evaluation
    if args.gt:
        gt_set = parse_gt(Path(args.gt))
        pred_set = set(out)
        tp = len(gt_set & pred_set)
        fp = len(pred_set - gt_set)
        fn = len(gt_set - pred_set)
        prec = tp/(tp+fp) if (tp+fp) else 0.0
        rec  = tp/(tp+fn) if (tp+fn) else 0.0
        f1   = (2*prec*rec)/(prec+rec) if (prec+rec) else 0.0
        iou  = tp/(tp+fp+fn) if (tp+fp+fn) else 0.0
        print(f"GT eval → TP:{tp} FP:{fp} FN:{fn}  Precision:{prec:.3f} Recall:{rec:.3f} F1:{f1:.3f} IoU-Acc:{iou:.3f}")

    if args.explain:
        if not X.empty:
            X.attrs.pop("unscaled", None)
            X.to_csv("features_scaled.csv")
        if not unscaled.empty:
            unscaled.to_csv("features_raw.csv")
        for name, sc in scores_out.items():
            if isinstance(sc, (pd.Series, pd.DataFrame)) and len(sc) > 0:
                if isinstance(sc, pd.DataFrame):
                    sc.to_csv(f"scores_{name}.csv")
                else:
                    sc.sort_values(ascending=False).to_csv(f"scores_{name}.csv")
        print("✓ Explain files written: features_scaled.csv, features_raw.csv, scores_*.csv")

if __name__ == "__main__":
    main()
